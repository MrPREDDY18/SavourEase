package com.example.savourease_app_kts

object UserStorage {

    // Map to store username -> password
    private val users = mutableMapOf(
        "admin" to "1234"
    )

    var loggedInUser: String? = null

    // Validate login credentials
    fun validateUser(username: String, password: String): Boolean {
        val validPassword = users[username]
        return validPassword != null && validPassword == password
    }

    // Register a new user
    fun addUser(username: String, password: String): Boolean {
        return if (users.containsKey(username)) {
            false // User already exists
        } else {
            users[username] = password
            true
        }
    }

    // Login a user
    fun login(username: String) {
        loggedInUser = username
    }

    // Logout
    fun logout() {
        loggedInUser = null
    }

    // Check login status
    fun isLoggedIn(): Boolean {
        return loggedInUser != null
    }
}
