package com.example.savourease_app_kts

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CheckoutActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        db = DatabaseHelper(this)

        val etCardName = findViewById<EditText>(R.id.etCardName)
        val etCardNumber = findViewById<EditText>(R.id.etCardNumber)
        val etExpiry = findViewById<EditText>(R.id.etExpiry)
        val etCvv = findViewById<EditText>(R.id.etCvv)
        val btnPay = findViewById<Button>(R.id.btnPay)

        btnPay.setOnClickListener {
            val name = etCardName.text.toString()
            val number = etCardNumber.text.toString()
            val expiry = etExpiry.text.toString()
            val cvv = etCvv.text.toString()

            if (name.isBlank() || number.isBlank() || expiry.isBlank() || cvv.isBlank()) {
                Toast.makeText(this, "Please fill in all details", Toast.LENGTH_SHORT).show()
            } else {
                db.addOrder(name, number, expiry, cvv)
                db.clearCart()
                Toast.makeText(this, "Payment successful! Order placed.", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, OrderTrackingActivity::class.java))
            }
        }
    }
}
