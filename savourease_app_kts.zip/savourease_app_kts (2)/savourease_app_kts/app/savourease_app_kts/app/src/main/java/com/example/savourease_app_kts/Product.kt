package com.example.savourease_app_kts

data class Product(
    val name: String,
    val price: Double
)
