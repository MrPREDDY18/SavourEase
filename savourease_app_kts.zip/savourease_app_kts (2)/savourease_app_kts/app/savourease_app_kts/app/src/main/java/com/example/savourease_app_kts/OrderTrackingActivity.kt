package com.example.savourease_app_kts

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class OrderTrackingActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_tracking)

        db = DatabaseHelper(this)

        val dot1 = findViewById<ImageView>(R.id.dot1)
        val dot2 = findViewById<ImageView>(R.id.dot2)
        val dot3 = findViewById<ImageView>(R.id.dot3)

        val line1 = findViewById<View>(R.id.line1)
        val line2 = findViewById<View>(R.id.line2)

        val tvStep1 = findViewById<TextView>(R.id.tvStep1)
        val tvStep2 = findViewById<TextView>(R.id.tvStep2)
        val tvStep3 = findViewById<TextView>(R.id.tvStep3)

        val btnBack = findViewById<Button>(R.id.btnBack)

        // Animate steps sequentially
        tvStep1.setTextColor(Color.BLACK)
        dot1.setColorFilter(Color.GREEN)

        handler.postDelayed({
            tvStep2.setTextColor(Color.BLACK)
            dot2.setColorFilter(Color.GREEN)
            line1.setBackgroundColor(Color.GREEN)
        }, 5000)

        handler.postDelayed({
            tvStep3.setTextColor(Color.BLACK)
            dot3.setColorFilter(Color.GREEN)
            line2.setBackgroundColor(Color.GREEN)
        }, 10000)

        btnBack.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
