package com.example.savourease_app_kts

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)

        val listProducts = findViewById<ListView>(R.id.listProducts)
        val btnCart = findViewById<Button>(R.id.btnCart)

        val products = listOf(
            Product("Samosa", 15.0),
            Product("Pie", 25.0),
            Product("Mix Platter", 50.0),
            Product("Spring Roll", 20.0)
        )

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = products.size
            override fun getItem(position: Int): Any = products[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val view = convertView ?: LayoutInflater.from(this@MainActivity)
                    .inflate(R.layout.item_product, parent, false)

                val tvProductInfo = view.findViewById<TextView>(R.id.tvProductInfo)
                val btnAddToCart = view.findViewById<Button>(R.id.btnAddToCart)

                val product = products[position]
                tvProductInfo.text = "${product.name} - R${product.price}"

                btnAddToCart.setOnClickListener {
                    db.addToCart(product.name, product.price)
                    Toast.makeText(this@MainActivity, "${product.name} added to cart", Toast.LENGTH_SHORT).show()
                }

                return view
            }
        }

        listProducts.adapter = adapter

        btnCart.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
    }
}
