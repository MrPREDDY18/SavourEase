package com.example.savourease_app_kts

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "savourease.db"
        private const val DB_VERSION = 1

        private const val TABLE_CART = "cart"
        private const val COL_ID = "id"
        private const val COL_PRODUCT_NAME = "product_name"
        private const val COL_PRICE = "price"

        private const val TABLE_ORDER = "orders"
        private const val COL_ORDER_ID = "order_id"
        private const val COL_CARD_NAME = "card_name"
        private const val COL_CARD_NUMBER = "card_number"
        private const val COL_EXPIRY = "expiry"
        private const val COL_CVV = "cvv"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createCartTable = """
            CREATE TABLE $TABLE_CART (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PRODUCT_NAME TEXT,
                $COL_PRICE REAL
            )
        """.trimIndent()

        val createOrderTable = """
            CREATE TABLE $TABLE_ORDER (
                $COL_ORDER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CARD_NAME TEXT,
                $COL_CARD_NUMBER TEXT,
                $COL_EXPIRY TEXT,
                $COL_CVV TEXT
            )
        """.trimIndent()

        db?.execSQL(createCartTable)
        db?.execSQL(createOrderTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_CART")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_ORDER")
        onCreate(db)
    }

    // Cart operations
    fun addToCart(name: String, price: Double) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_PRODUCT_NAME, name)
        values.put(COL_PRICE, price)
        db.insert(TABLE_CART, null, values)
        db.close()
    }

    fun getCartItems(): List<Product> {
        val list = mutableListOf<Product>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_CART", null)
        if (cursor.moveToFirst()) {
            do {
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_PRODUCT_NAME))
                val price = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PRICE))
                list.add(Product(name, price))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    fun deleteCartItem(name: String) {
        val db = writableDatabase
        db.delete(TABLE_CART, "$COL_PRODUCT_NAME=?", arrayOf(name))
        db.close()
    }

    fun clearCart() {
        val db = writableDatabase
        db.delete(TABLE_CART, null, null)
        db.close()
    }

    // Order operations
    fun addOrder(cardName: String, cardNumber: String, expiry: String, cvv: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_CARD_NAME, cardName)
        values.put(COL_CARD_NUMBER, cardNumber)
        values.put(COL_EXPIRY, expiry)
        values.put(COL_CVV, cvv)
        db.insert(TABLE_ORDER, null, values)
        db.close()
    }

    fun getLastOrder(): Map<String, String>? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_ORDER ORDER BY $COL_ORDER_ID DESC LIMIT 1", null)
        var order: Map<String, String>? = null
        if (cursor.moveToFirst()) {
            order = mapOf(
                COL_CARD_NAME to cursor.getString(cursor.getColumnIndexOrThrow(COL_CARD_NAME)),
                COL_CARD_NUMBER to cursor.getString(cursor.getColumnIndexOrThrow(COL_CARD_NUMBER)),
                COL_EXPIRY to cursor.getString(cursor.getColumnIndexOrThrow(COL_EXPIRY)),
                COL_CVV to cursor.getString(cursor.getColumnIndexOrThrow(COL_CVV))
            )
        }
        cursor.close()
        db.close()
        return order
    }
}
