package com.example.savourease_app_kts

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CartActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var listCart: ListView
    private lateinit var btnCheckout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        db = DatabaseHelper(this)

        listCart = findViewById(R.id.listCart)
        btnCheckout = findViewById(R.id.btnCheckout)

        refreshCart()

        btnCheckout.setOnClickListener {
            if (db.getCartItems().isEmpty()) {
                Toast.makeText(this, "Cart is empty!", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, CheckoutActivity::class.java))
            }
        }
    }

    private fun refreshCart() {
        val cartItems = db.getCartItems()
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = cartItems.size
            override fun getItem(position: Int): Any = cartItems[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val view = convertView ?: LayoutInflater.from(this@CartActivity)
                    .inflate(R.layout.item_cart, parent, false)

                val tvProductInfo = view.findViewById<TextView>(R.id.tvProductInfo)
                val btnDelete = view.findViewById<Button>(R.id.btnDelete)

                val product = cartItems[position]
                tvProductInfo.text = "${product.name} - R${product.price}"

                btnDelete.setOnClickListener {
                    db.deleteCartItem(product.name)
                    refreshCart()
                    Toast.makeText(this@CartActivity, "${product.name} removed", Toast.LENGTH_SHORT).show()
                }

                return view
            }
        }

        listCart.adapter = adapter
    }
}
