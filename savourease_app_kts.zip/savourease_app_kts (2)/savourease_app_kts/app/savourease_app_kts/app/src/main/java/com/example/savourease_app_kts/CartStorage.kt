package com.example.savourease_app_kts

object CartStorage {
    val cart = mutableListOf<Product>()
}
