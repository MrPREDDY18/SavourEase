
package com.savourease.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val emailField = findViewById<EditText>(R.id.et_email)
        val passField = findViewById<EditText>(R.id.et_password)
        val confirmField = findViewById<EditText>(R.id.et_confirm)
        findViewById<Button>(R.id.btn_signup).setOnClickListener {
            val email = emailField.text.toString().trim()
            val pass = passField.text.toString()
            val conf = confirmField.text.toString()
            if (pass != conf) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (email.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "Provide email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val prefs = getSharedPreferences("auth", MODE_PRIVATE)
            prefs.edit().putString(email, pass).apply()
            Toast.makeText(this, "Account created. Log in.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
