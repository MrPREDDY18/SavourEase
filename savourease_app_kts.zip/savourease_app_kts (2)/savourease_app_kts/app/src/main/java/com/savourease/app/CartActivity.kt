
package com.savourease.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        val container = findViewById<LinearLayout>(R.id.ll_cart)
        refreshCart(container)

        findViewById<Button>(R.id.btn_checkout).setOnClickListener {
            startActivity(Intent(this, CheckoutActivity::class.java))
        }
        findViewById<Button>(R.id.btn_clear).setOnClickListener {
            DataStore.cart.clear()
            refreshCart(container)
        }
    }

    private fun refreshCart(container: LinearLayout) {
        container.removeAllViews()
        DataStore.cart.forEach { c ->
            val tv = TextView(this)
            tv.text = "${c.name} - R${c.price} x ${c.quantity}"
            tv.textSize = 18f
            tv.setPadding(20,20,20,20)
            container.addView(tv)
        }
        val total = DataStore.cart.sumOf { it.price * it.quantity }
        findViewById<TextView>(R.id.tv_total).text = "Total: R$total"
    }
}
