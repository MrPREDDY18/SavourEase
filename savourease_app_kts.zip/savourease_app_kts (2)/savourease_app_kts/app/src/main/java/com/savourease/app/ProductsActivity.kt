
package com.savourease.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProductsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        val container = findViewById<LinearLayout>(R.id.ll_products)
        DataStore.products.forEach { p ->
            val tv = TextView(this)
            tv.text = "${p.name} - R${p.price}"
            tv.textSize = 18f
            tv.setPadding(20,20,20,20)
            tv.setOnClickListener {
                // add to cart
                DataStore.cart.add(CartItem(p.id, p.name, p.price, 1))
                Toast.makeText(this, "Added ${p.name} to cart", Toast.LENGTH_SHORT).show()
            }
            container.addView(tv)
        }

        findViewById<Button>(R.id.btn_view_cart).setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
        findViewById<Button>(R.id.btn_contact).setOnClickListener {
            startActivity(Intent(this, ContactActivity::class.java))
        }
    }
}
