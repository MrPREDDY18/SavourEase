
package com.savourease.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class CheckoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        val cardField = findViewById<EditText>(R.id.et_card)
        findViewById<Button>(R.id.btn_pay).setOnClickListener {
            val card = cardField.text.toString().trim()
            if (card.length < 12) {
                Toast.makeText(this, "Enter a valid mock card", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val total = DataStore.cart.sumOf { it.price * it.quantity }
            val order = Order(UUID.randomUUID().toString(), DataStore.cart.toList(), total, "Preparing")
            DataStore.orders.add(order)
            DataStore.cart.clear()
            Toast.makeText(this, "Payment successful (mock). Order placed.", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
