
package com.savourease.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ContactActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)

        val name = findViewById<EditText>(R.id.et_name)
        val email = findViewById<EditText>(R.id.et_email)
        val msg = findViewById<EditText>(R.id.et_message)
        findViewById<Button>(R.id.btn_send).setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("support@savourease.local"))
                putExtra(Intent.EXTRA_SUBJECT, "Contact from ${'$'}{name.text}")
                putExtra(Intent.EXTRA_TEXT, msg.text.toString())
            }
            startActivity(intent)
        }
    }
}
