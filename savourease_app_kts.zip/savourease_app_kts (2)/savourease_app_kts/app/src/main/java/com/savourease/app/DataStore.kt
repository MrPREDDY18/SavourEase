
package com.savourease.app

data class Product(val id: String, val name: String, val description: String, val price: Double, var stock: Int)
data class CartItem(val productId: String, val name: String, val price: Double, var quantity: Int)
data class Order(val id: String, val items: List<CartItem>, val total: Double, var status: String)

object DataStore {
    val products = mutableListOf(
        Product("p1", "Cheese Roll", "Buttery cheese roll", 12.0, 20),
        Product("p2", "Sausage Roll", "Savory sausage roll", 10.5, 18),
        Product("p3", "Veggie Slice", "Vegetable savoury slice", 9.0, 15),
        Product("p4", "Chicken Puff", "Crispy chicken puff", 14.0, 10)
    )
    val cart = mutableListOf<CartItem>()
    val orders = mutableListOf<Order>()
}
