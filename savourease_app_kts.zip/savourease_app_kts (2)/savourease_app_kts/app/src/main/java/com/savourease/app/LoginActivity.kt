
package com.savourease.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailField = findViewById<EditText>(R.id.et_email)
        val passField = findViewById<EditText>(R.id.et_password)
        findViewById<Button>(R.id.btn_login).setOnClickListener {
            val email = emailField.text.toString().trim()
            val pass = passField.text.toString()

            val prefs = getSharedPreferences("auth", MODE_PRIVATE)
            val saved = prefs.getString(email, null)
            if (saved != null && saved == pass) {
                startActivity(Intent(this, ProductsActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "No user found or wrong password. Try signing up.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btn_signup).setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }
}
