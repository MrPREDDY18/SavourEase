rootProject.name = "Savourease"
include(":app")