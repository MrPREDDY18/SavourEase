const express = require('express');
const sql = require('./db');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// --------------------
// Register User
// --------------------
app.post('/register', async (req, res) => {
    const { username, password, email } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        await sql.query`
            INSERT INTO Users (Username, PasswordHash, Email)
            VALUES (${username}, ${hashedPassword}, ${email})
        `;
        res.json({ message: "User registered successfully" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// --------------------
// Login User
// --------------------
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const result = await sql.query`SELECT * FROM Users WHERE Username = ${username}`;
        if (result.recordset.length === 0) return res.status(400).json({ error: "User not found" });

        const user = result.recordset[0];
        const match = await bcrypt.compare(password, user.PasswordHash);
        if (!match) return res.status(400).json({ error: "Incorrect password" });

        res.json({ message: "Login successful", username: user.Username, userId: user.Id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --------------------
// Fetch Products
// --------------------
app.get('/products', async (req, res) => {
    try {
        const result = await sql.query`SELECT * FROM Products`;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --------------------
// Save Order
// --------------------
app.post('/order', async (req, res) => {
    const { userId, total, paymentMethod, items } = req.body;

    try {
        const orderResult = await sql.query`
            INSERT INTO Orders (UserId, Total, PaymentMethod)
            OUTPUT INSERTED.Id
            VALUES (${userId}, ${total}, ${paymentMethod})
        `;
        const orderId = orderResult.recordset[0].Id;

        for (let item of items) {
            await sql.query`
                INSERT INTO OrderItems (OrderId, ProductId, Quantity, Price)
                VALUES (${orderId}, ${item.productId}, ${item.quantity}, ${item.price})
            `;
        }

        res.json({ message: "Order saved successfully", orderId });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --------------------
// Get Orders for a User
// --------------------
app.get('/orders/:userId', async (req, res) => {
    const { userId } = req.params;
    try {
        const result = await sql.query`SELECT * FROM Orders WHERE UserId = ${userId}`;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(3000, () => console.log('Server running at http://localhost:3000'));
