const sql = require('mssql');

const config = {
    user: 'root',
    password: '',
    server: 'localhost',
    database: 'SavourEaseDB',
    options: {
        trustServerCertificate: true
    }
};

sql.connect(config)
    .then(() => console.log("Connected to SQL Server"))
    .catch(err => console.error("Database connection failed", err));

module.exports = sql;
