document.getElementById('menu-icon').addEventListener('click', function () {
    var navbar = document.getElementById('navbar');
    navbar.classList.toggle('open');
});


function updateClock() {
    const currentTime = new Date();
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const seconds = currentTime.getSeconds();

    const formattedHours = hours < 10 ? '0' + hours : hours;
    const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
    const formattedSeconds = seconds < 10 ? '0' + seconds : seconds;

    const timeString = formattedHours + ':' + formattedMinutes + ':' + formattedSeconds;

    document.getElementById('digital-clock').textContent = timeString;
}

// Update the clock every second
setInterval(updateClock, 1000);

// Initial update
updateClock();

function submitAnswer() {
    const userInput = document.getElementById('input-field').value;
    const answerContainer = document.getElementById('answer-container');
    
    // Replace this with your AI logic or API call to get responses
    const aiResponse = getAiResponse(userInput);

    // Display the AI response
    answerContainer.textContent = aiResponse;

    // Clear the input field
    document.getElementById('input-field').value = '';
}

function getAiResponse(userInput) {
    // Convert user input to lowercase for case-insensitive matching
    const lowerCaseInput = userInput.toLowerCase();

    // Simple AI logic based on keywords
    if (lowerCaseInput.includes('hello') || lowerCaseInput.includes('hi')) {
        return "Hello! How can I assist you today?";
    } else if (lowerCaseInput.includes('how are you')) {
        return "I'm just a computer program, but thanks for asking!";
    } else if (lowerCaseInput.includes('your name')) {
        return "I'm a basic AI assistant. You can call me Assistant.";
    } else if (lowerCaseInput.includes('time')) {
        const currentTime = new Date();
        const hours = currentTime.getHours();
        const minutes = currentTime.getMinutes();

        const formattedHours = hours < 10 ? '0' + hours : hours;
        const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;

        return `The current time is ${formattedHours}:${formattedMinutes}.`;
    } else if (lowerCaseInput.includes('weather')) {
        return "I'm sorry, I don't have real-time weather information. You may want to check a weather website.";
    } else if (lowerCaseInput.includes('joke')) {
        // Replace this with a call to a joke API or include your own set of jokes
        return "Why don't scientists trust atoms? Because they make up everything!";
    } else if (lowerCaseInput.includes('meaning of life')) {
        return "The meaning of life is a philosophical question. It's different for everyone!";
    } else if (lowerCaseInput.includes('bye') || lowerCaseInput.includes('goodbye')) {
        return "Goodbye! If you have more questions, feel free to ask.";
    } else {
        return "I'm sorry, I didn't understand that. Can you please rephrase or ask another question?";
    }
}

let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function showSlides(n) {
  const slides = document.getElementsByClassName("slide");
  if (slides.length === 0) return;

  if (n > slides.length) { slideIndex = 1 }
  if (n < 1) { slideIndex = slides.length }

  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  slides[slideIndex - 1].style.display = "block";
}

window.plusSlides = plusSlides;